import re


#Funciones de validacion 

def validacion_num(msj):              #Funcion de validacion numerica
    
    """Función para validar la entrada de datos numericos con un limite de 3 intentos por medio  de un ciclo 
    de un ciclo y confirmando la entra con la libreria re usando re.match
    El mensaje (msj) que se mostrará al usuario para solicitar la entrada.
    Solo va a retornar:
    int or None: Si la entrada es un numero valido, se devuelve el numero como entero.
                Si se excede el número maximo de intentos, devuelve None."""

    a = 0
    while a < 3:
        entrada = input(msj)
        try:
            if re.match('^\d+$', entrada):          #Verifica que la entrada solo sea de valores numericos 
                return int(entrada)
            else:
                print("Solo puede ingresar valores numericos.")
                a += 1
        except ValueError:
            print("Se presenta un error")
            a += 1

    print("Has excedido el numero maximo de intentos .")
    return None

def validacion_alfanumerico(msj):             #Funcion de validacion alfanumerica

    """Función para validar la entrada de datos alfanuméricos con un límite de 3 intentos con un ciclo y 
    verificando la entrada con re.match 
    El mensaje que se mostrará al usuario para solicitar la entrada.
    La funcion va retornar:
    str or None: Si la entrada es alfanumerica válida, se devuelve la entrada como string.
                Si se excede el número máximo de intentos, devuelve None."""

    d = 0
    while d < 3:
        entrada = input(msj)
        try:
            if re.match('^[a-zA-Z0-9]+$', entrada):            #Verifica que la entrada solo sea de valores alfanumericos
                return entrada
            else:
                print("Solo puede ingresar valores alfanumericos.")
                d += 1
        except ValueError:
            print("Se presenta un error")
            d += 1
    
    print("Has excedido el número maximo de intentos.")
    return None 

def validacion_alfabetico(msj):                  #Funcion de validacion alfabetica 
    """Funcion para validar la entrada de datos alfabéticos con un limite de 3 intentos por medio de un ciclo
    El mensaje que se mostrará al usuario para solicitar la entrada
    Retorno : Si la entrada es alfabetica valida, se devuelve la entrada como string.
                Si se excede el número maximo de intentos, devuelve None"""
    l = 0
    while l < 3:
        entrada = input(msj)
        try:
            if entrada.isalpha():   #Verifica que la entrada sea exclusivamente de caracteres alfabeticos
                return entrada
            else:
                print("Solo puede ingresar valores alfabeticos")
                l += 1
        except ValueError:
            print("Se presenta un error")
            l+= 1

    print("Has excedido el número maximo de intentos")
    return None  

def validacion_float(msj):              #Funcion de validacion numerica
    
    """Función para validar la entrada de datos flotantes con un limite de 3 intentos por medio  de un ciclo 
    de un ciclo y confirmando la entra con la libreria re usando re.match
    El mensaje (msj) que se mostrará al usuario para solicitar la entrada.
    Solo va a retornar:
    int or None: Si la entrada es un numero valido, se devuelve el numero como entero.
                Si se excede el número maximo de intentos, devuelve None."""

    a = 0
    while a < 3:
        entrada = input(msj)
        try:
            if re.match('^\d+$', entrada):          #Verifica que la entrada solo sea de valores flotantes 
                return float(entrada)
            else:
                print("Solo puede ingresar valores flotantes.")
                a += 1
        except ValueError:
            print("Se presenta un error")
            a += 1

    print("Has excedido el numero maximo de intentos .")
    return None  


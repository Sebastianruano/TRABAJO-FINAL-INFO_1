#Santiago Nicolas Ramirez C.C 1004532606
#Juan Sebatian Ruano C.C 1085896282

from pymongo import MongoClient
import pymongo
from pymongo.errors import ConnectionFailure
import json
import os 
import json
import mysql.connector
from validaciones import* 
from admin.almacenamiento import*
from funciones import*
import datetime

#Proceso de login 


while True:
    print("RESULTADO DE PRUEBAS LABORATORIO DE BIOMATERIALES".center(90))
    ingre=validacion_num("Opcion de tipo de ingreso\n1.Como administrador\n2.Responsable?\n3.Resultados de prueba\n4.salir")

    try:
        if ingre==1:                     #Ingreso como administrador 
            user=validacion_alfanumerico("Usuario") 
            cont=validacion_num("Clave")
            resultado=login_admin(user, cont)        #Login para permitir acceso a menu

            while resultado==True:
                #Estableciendo el menu de administrativos 
                menu=validacion_num("""                
                    Ingrese su opcion\n
                    1. Crear usuario administrador\n
                    2. Ver usuario administrador\n
                    3. Actualizar la información de un administrador.\n
                    4. Eliminar un administrador.\n
                    6. Ver la información de resonsable de prueba.\n
                    7. Actualizar la información de responsable de prueba.\n
                    8. Ver la información de todas las pruebas alamacenadas.\n
                    9. Ver materiales estudiados por los difrentes responsables
                    10. Eliminar un responsable.\n
                    11. Volver al menú principal\n""")
                try:
                    if menu == 1:
                        n = input("Ingrese sus dos nombres y su apellido :\n").title()
                        c = input("ingrese la clave:\n")
                        doc = input("Ingrese su cedula:\n")

                        agregar_admin(doc, n, c)


                    elif menu ==2 :                 # Ver usuario administrador\
                        ruta = "admin/users.xml"
                        n = input("Ingrese el id del administrativo que desea visualizar: ")
                        ver_usuario(ruta, n)

                    elif menu == 3:
                        ruta = "admin/users.xml"
                        admin_id = input("Ingrese el ID del administrador que desea actualizar: ")
                        datos_actualizados = {
                            "nombre": input("Ingrese el nuevo nombre: "),
                            "clave": input("Ingrese la nueva clave: ")
                        }
                        actualizacion_admin(ruta, admin_id, datos_actualizados)

                    elif menu == 4:
                        ruta = "users.xml"
                        admin_id = input("Ingrese el ID del administrador que desea eliminar: ")
                        eliminar_admin(ruta, admin_id)

                    elif menu== 5:
                        print("Ingrese la informacion del nuevo responsable:\n")
                        codigo_responsable = int(input("Ingrese el código del responsable: "))
                        contraseña = input("Ingrese la contraseña: ")
                        apellido = input("Ingrese el apellido: ")
                        nombre = input("Ingrese el nombre: ")
                        numero_documento_identidad = int(input("Ingrese el número del documento de identidad: "))
                        cargo = input("Ingrese el cargo: ")

                        conexion_mysql = conectar_mysql()
                        agregar_responsable_mysql(conexion_mysql, codigo_responsable, contraseña, apellido, nombre, numero_documento_identidad, cargo)
                        conexion_mysql.close()
                        # Conectar a MongoDB y agregar responsable
                        agregar_responsable_mongo(codigo_responsable, contraseña, apellido, nombre, numero_documento_identidad, cargo)

                    elif menu ==6:
                        d = validacion_num("Ingrese su opción:\n1.Ver info en MySQL\n2.Ver info en MongoDB:\n")
                        if d == 1:  # Ver info en MySQL
                            conexion = conectar_mysql()
                            if conexion:
                                doc = validacion_num("Ingrese el número de documento de identidad del responsable:")
                                resultado = buscar_1(conexion, 'Responsables', doc)
                                if resultado:
                                    codigo_responsable, contraseña, apellido, nombre, numero_documento_identidad, cargo = resultado[0]

                                    # Imprimir la información completa
                                    print("Código Responsable:", codigo_responsable)
                                    print("Contraseña:", contraseña)
                                    print("Apellido:", apellido)
                                    print("Nombre:", nombre)
                                    print("Número de Documento de Identidad:", numero_documento_identidad)
                                    print("Cargo:", cargo)
                                else:
                                    print("No se encontró un responsable con ese número de documento de identidad.")
                                conexion.close()
                            else:
                                print("No se pudo conectar a la base de datos MySQL.")
                        elif d == 2:  # Ver info en MongoDB
                            id_responsable = validacion_num("Ingrese el código del responsable a buscar:")
                            datos_responsable = buscar_ID('Responsables', id_responsable)
                            if datos_responsable:
                                codigo_responsable = datos_responsable.get('codigo_responsable')
                                contraseña = datos_responsable.get('contraseña')
                                apellido = datos_responsable.get('apellido')
                                nombre = datos_responsable.get('nombre')
                                numero_documento_identidad = datos_responsable.get('numero_documento_identidad')
                                cargo = datos_responsable.get('cargo')

                                # Imprimir la información completa
                                print("Código Responsable:", codigo_responsable)
                                print("Contraseña:", contraseña)
                                print("Apellido:", apellido)
                                print("Nombre:", nombre)
                                print("Número de Documento de Identidad:", numero_documento_identidad)
                                print("Cargo:", cargo)
                            else:
                                print("No se encontró un responsable con ese código en MongoDB.")

                    elif menu == 7:

                        numero_documento_identidad = validacion_num("Ingrese el número de documento de identidad del responsable a actualizar:")
                        nuevo_nombre = input("Ingrese el nuevo nombre del responsable:")
                        nuevo_apellido = input("Ingrese el nuevo apellido del responsable:")
                        nueva_contrasena = input("Ingrese la nueva contraseña del responsable:")
                        nuevo_cargo = input("Ingrese el nuevo cargo del responsable:")

                        conexion = conectar_mysql()
                        edit_mysql(conexion, numero_documento_identidad, nuevo_nombre, nuevo_apellido, nueva_contrasena, nuevo_cargo)
                        edit_mongo(numero_documento_identidad, nuevo_nombre, nuevo_apellido, nueva_contrasena, nuevo_cargo)

                    elif menu==8:
                        d = validacion_num("Ingrese su opción:\n1. Ver pruebas en MySQL\n2. Ver pruebas en MongoDB:\n")
                        if d == 1:
                            ver_pruebas_mysql()
                        elif d == 2:
                            ver_pruebas_mongodb()

                    elif menu == 9:
                        d = validacion_num("Ingrese su opción:\n1. Ver materiales estudiados en MySQL\n2. Ver materiales estudiados en MongoDB\n3. Salir\n")
                        if d == 1:
                            ver_materiales_mysql()
                        elif d == 2:
                            ver_materiales_mongodb()
                        elif d == 3:
                            print("Volviendo al menú principal...")
                            break
                        else:
                            print("Opción no válida, por favor intente de nuevo.")

                    elif menu == 10:
                        conexion = conexion_mysql()
                        codigo_responsable = validacion_num("Ingrese el código del responsable a eliminar: ")
                        # Eliminar de MongoDB
                        eliminar_mongo('Responsables', codigo_responsable)
                        # Eliminar de MySQL
                        eliminar_msql(conexion, 'Responsables', codigo_responsable)


                    elif menu==11:                       #Volver al menu
                            break

                except ValueError:
                    print("Escoja una opcion correcta de submenu")
                    continue

        elif ingre==2:                   #Ingreso como responsable
            usuario=input("Ingresar usuario :")
            valor=validacion_num("Ingrese su contrseña:\n")
            resultado=login_responsable(valor,usuario)

            while resultado==True:
                menu=validacion_num("""
                1. Cambiar contraseña\n 
                2. Ver datos personales\n 
                3. Actualizar datos personales\n 
                4. Ingresar nuevo resultado de prueba de material\n 
                5. Importar resultados de prueba.\n 
                6. Actualizar  la  información  de  resultados  de  pruebas.\n 
                7. Ver  la  información  del  resultado  una  de  las  pruebas  de  material.\n 
                8. Ver todos los resultados de todas la pruebas realizadas.\n  
                9. Eliminar un resultado de prueba.\n 
                10.   Volver al menú principal\n
                """) 
                try:
                    if menu == 1:
                        # Conectar a MySQL
                        conexion_mysql = conectar_mysql()
                        if conexion_mysql:
                            # Obtener los datos del usuario
                            usuario = input("Ingresa tu nombre de usuario: ") 
                            contraseña_actual = input("Ingresa tu contraseña actual: ")
                            nueva_contraseña = input("Ingresa tu nueva contraseña: ")

                            # Llamar a la función para cambiar la contraseña
                            if cambiar_contraseña(conexion_mysql, usuario, contraseña_actual, nueva_contraseña):
                                print("Cambio de contraseña exitoso.")
                            else:
                                print("No se pudo cambiar la contraseña.")

                            # Cerrar la conexión a MySQL
                            conexion_mysql.close()
                        else:
                            print("No se pudo establecer la conexión con la base de datos MySQL.")
                    elif menu == 2:

                        # Establecer la conexión con la base de datos MySQL
                        conexion = conectar_mysql()

                        # Crear un cursor para ejecutar las consultas
                        cursor = conexion.cursor()

                        usuario = input("Ingresa tu nombre de usuario: ")
                        # Consulta para obtener los datos personales del responsable
                        sql = "SELECT nombre, apellido, numero_documento_identidad, cargo FROM Responsables WHERE usuario = %s"
                        cursor.execute(sql, (usuario,))

                        # Obtener y mostrar los resultados de la consulta
                        resultado = cursor.fetchone()
                        if resultado:
                            datos_personales = {
                                "nombre": resultado[0],
                                "apellido": resultado[1],
                                "numero_documento_identidad": resultado[2],
                                "cargo": resultado[3]
                            }
                            for key, value in datos_personales.items():
                                print(f"{key}: {value}")
                        else:
                            print("No se encontraron datos para el usuario proporcionado.")

                        # Cerrar el cursor y la conexión
                        cursor.close()
                        conexion.close()

                    elif menu ==3:
                        usuario = input("Ingresa el nombre de usuario del responsable: ")
                        nuevo_nombre = input("Ingresa el nuevo nombre: ")
                        nuevo_apellido = input("Ingresa el nuevo apellido: ")
                        nuevo_numero_documento_identidad = input("Ingresa el nuevo número de documento de identidad: ")
                        nuevo_cargo = input("Ingresa el nuevo cargo: ")

                        # Llamar a la función de actualización con los datos recogidos
                        actualizar_datos_personales(usuario, nuevo_nombre, nuevo_apellido, nuevo_numero_documento_identidad, nuevo_cargo)

                    elif menu == 4:
                        conexion_mysql = conectar_mysql()
                        if conexion_mysql is None:
                            print("No se pudo conectar a la base de datos MySQL.")
                        else:
                            serial_probeta = input("Ingresa el serial de la probeta: ")
                            nombre_material = input("Ingresa el nombre del material: ")
                            resultado_ensayo_traccion = validacion_float(input("Ingresa el resultado del ensayo de tracción: "))
                            resultado_prueba_dureza = validacion_num(input("Ingresa el resultado de la prueba de dureza: "))
                            resultado_prueba_hemocompatibilidad = input("Ingresa el resultado de la prueba de hemocompatibilidad (Sí/No): ")
                            resultado_prueba_inflamabilidad = input("Ingresa el resultado de la prueba de inflamabilidad (Sí/No): ")
                            resultado_densidad = validacion_float(input("Ingresa el resultado de densidad: "))
                            resultado_temperatura_fusion = validacion_num(input("Ingresa el resultado de la temperatura de fusión: "))
                            fecha_realizacion = input("Ingresa la fecha de realización (YYYY-MM-DD): ")
                            responsable_id = mostrar_responsables_y_seleccionar(conexion_mysql)

                            insertar_nuevo_resultado(serial_probeta, nombre_material, resultado_ensayo_traccion, 
                                                    resultado_prueba_dureza, resultado_prueba_hemocompatibilidad, 
                                                    resultado_prueba_inflamabilidad, resultado_densidad, 
                                                    resultado_temperatura_fusion, fecha_realizacion, responsable_id)
                    
                    elif menu ==5:
                        # Ruta del archivo JSON
                        ruta_resultados_json = 'datos_iniciales/resultados.json'
                        # Leer datos JSON desde el archivo
                        resultados_json_data = leer_json(ruta_resultados_json)
                        # Llamar a la función de importación con los datos recogidos
                        importar_resultados_prueba(resultados_json_data)
                    elif menu==6:   
                         serial_probeta = int(input("Ingrese el número de serie de la probeta a actualizar: "))
                         nuevos_datos = {
                            "nombre_material": input("Ingrese el nuevo nombre del material: "),
                            "resultado_traccion": float(input("Ingrese el nuevo resultado de tracción: ")),
                            "resultado_dureza": int(input("Ingrese el nuevo resultado de dureza: ")),
                            "resultado_hemocompatibilidad": input("El nuevo resultado de hemocompatibilidad es verdadero (True) o falso (False)? ").lower() == "true",
                            "resultado_inflamabilidad": input("El nuevo resultado de inflamabilidad es verdadero (True) o falso (False)? ").lower() == "true",
                            "resultado_densidad": float(input("Ingrese el nuevo resultado de densidad: ")),
                            "resultado_temperatura_fusion": int(input("Ingrese la nueva temperatura de fusión: ")),
                            "fecha_realizacion": datetime.strptime(input("Ingrese la nueva fecha de realización (AAAA-MM-DD): "), "%Y-%m-%d"),
                            "codigo_responsable": int(input("Ingrese el código del nuevo responsable: "))
                             }
                         actualizar_resultados_prueba(serial_probeta, nuevos_datos)
                         print("Resultados de la prueba actualizados correctamente.")
                    elif menu==7:
                            serial_probeta = int(input("Ingrese el número de serie de la probeta a buscar: "))
                            ver_informacion_prueba_mysql(serial_probeta)
                            ver_informacion_prueba_mongodb(serial_probeta)     

                    elif menu==8:
                        ver_series_fechas_mysql()
                        ver_series_fechas_mongodb()
                    elif menu==9:
                            serial_probeta_a_eliminar = int(input("Ingrese el número de serie de la probeta a eliminar: "))
                            eliminar_resultado_mysql(serial_probeta_a_eliminar)
                            eliminar_resultado_mongodb(serial_probeta_a_eliminar)
    
                    elif menu==10:                       #Volver al menu
                        break

                except ValueError:
                    print("Escoja una opcion correcta de submenu")
                    continue
        else:                            #Salir
            ingre=validacion_num("Ingrese tipo de usuario para salir:\n1.Administrador\2.Responsable ")
            try:
                if ingre==1:                   #Salida como administrador
                    user=input("Ingrese su usuario: ")
                    cont=input("Ingrese su contraseña: ")
                    d=login_admin(user,cont)
                    if d==True:
                        break
                    else:
                        print("Usuario o contraseña incorrecta")
                else:                            #Salida como responsable
                    correo=input("Ingreso de correo: ")
                    valor=input("Ingreso de contraeña:  ")
                    d=login_responsable(valor,correo)
                    if d==True:
                        break
                    else:
                        print("Usuario o contraseña incorrecta")
            except ValueError:
                print("Opcion incorrecta de menu")

    except ValueError:
        print(f"La opcion {ingre} no se encuentra en el menu.Elija una opcion valida")
